/*******************************************************************************
* File Name: helper_functions.c
*
* Description:
*  Functions used by main.
*  basically EEPROM functions at this point.
*
**********************************************************************************
* Copyright Highland Biosciences Ltd
* Copyright Naresuan University, Phitsanulok Thailand
* Released under Creative Commons Attribution-ShareAlike  3.0 (CC BY-SA 3.0 US)
*********************************************************************************/

#include "helper_functions.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char8 LCD_str_top[MAX_LCD_BYTES];                       // buffer for LCD screen, make it extra big to avoid overflow
char8 LCD_str_bot[MAX_LCD_BYTES];    

/******************************************************************************
* Function Name: helper_uint2char
*******************************************************************************
*
* Summary:
*    Start the eepromm, update the temperature and write a byte to it
*
* Parameters:
*     data: the byte to write in
*
* Return:
*
*******************************************************************************/

char* helper_uint2char(uint8_t *data)
{
    size_t length = strlen((char *)data);           // Use strlen to determine the length of the null-terminated string
    char *char_data = (char *)malloc(length + 1);   // Allocate memory for the new string, including space for the null terminator
    if (char_data == NULL) return NULL;
        
    for (size_t i = 0; i < length; i++) {           // Copy the data from the uint8_t array to the char array
        char_data[i] = (char)data[i];
    }

    char_data[length] = '\0';                       // Null-terminate the string

return char_data;
    
}
  
    

/******************************************************************************
* Function Name: helper_Writebyte_EEPROM
*******************************************************************************
*
* Summary:
*    Start the eepromm, update the temperature and write a byte to it
*
* Parameters:
*     data: the byte to write in
*     address: the address to write the data at
*
* Return:
*
*******************************************************************************/

uint8_t helper_Writebyte_EEPROM(uint8_t data, uint16_t address) {
    EEPROM_Start();
    EEPROM_UpdateTemperature();
    uint8_t write_results = EEPROM_WriteByte(data, address);
    EEPROM_Stop();
    return write_results;
}

/******************************************************************************
* Function Name: helper_Readbyte_EEPROM
*******************************************************************************
*
* Summary:
*    Start the eepromm, update the temperature and read a byte to it
*
* Parameters:
*     address: the address to read the data from
*
* Return:
*     data that was read
*
*******************************************************************************/

uint8_t helper_Readbyte_EEPROM(uint16_t address) {
    EEPROM_Start();
    CyDelayUs(10);
    EEPROM_UpdateTemperature();
    CyDelayUs(10);
    uint8_t data = EEPROM_ReadByte(address);
    EEPROM_Stop();
    return data;
}

/******************************************************************************
* Function Name: helper_HardwareInit
*******************************************************************************
*
* Summary:
*    Start all the hardware needed for an experiment.
*
*******************************************************************************/
void helper_HardwareInit(void){ 
 
    /* setup the communications */
    Clock_PWM_Start();    
    
    /* Initialise system timing */
    PWM_M_Start();
    PWM_S_Start();
    
    
    /* Voltage Control Circuit */  
    VDAC_Poise_Init();   
    Opamp_Aux_Init();
    
   
    /* Current Measuring Circuit */
    ADC_DelSig_Init();
    VDAC_TIA_Init();
    TIA_Init();
    IDAC_calibrate_Init();
    
    
}

/******************************************************************************
* Function Name: helper_Hardware Enable
*******************************************************************************
*
* Summary:
*    Start all the hardware needed for an experiment.
*
*******************************************************************************/
void helper_HardwareEnable(void){ 
 
    /* setup the communications and system timing */                             
    PWM_M_Enable();
    PWM_S_Enable();
    
    /* Voltage Control Circuit */  
    VDAC_Poise_Enable();
    Opamp_Aux_Enable();
    
     /* Current Measuring Circuit */   
    ADC_DelSig_Enable();
    VDAC_TIA_Enable();
    TIA_Enable();
 
    
}

/******************************************************************************
* Function Name: helper_HardwareSleep
*******************************************************************************
*
* Summary:
*    Put to sleep all the hardware needed for an experiment.
*
*******************************************************************************/
void helper_HardwareSleep(void){  
    
    /* Voltage Control Circuit */  
    VDAC_Poise_Sleep();
    Opamp_Aux_Sleep();
    
    /* Current Measuring Circuit */
    // ADC_DelSig_Sleep();
    VDAC_TIA_Sleep();
    TIA_Sleep();  
}


/******************************************************************************
* Function Name: helper_HardwareWakeup
*******************************************************************************
*
* Summary:
*    Start all the hardware needed for an experiment.
*
*******************************************************************************/
void helper_HardwareWakeup(void){  // wakeup all the components that have to be on for a reading
        
    /* Voltage Control Circuit */  
    VDAC_Poise_Wakeup();
    Opamp_Aux_Wakeup();
    
    /* Current Measuring Circuit */
    ADC_DelSig_Wakeup();
    VDAC_TIA_Wakeup();
    TIA_Wakeup();  
        
}


/******************************************************************************
* Function Name: helper_WipeLCD
*******************************************************************************
*
* Summary: Wipe the LCD buffers ready for new messages
*
*******************************************************************************/

void helper_WipeLCD(void){  // wipe the text 
memset(LCD_str_top, 0, MAX_LCD_BYTES);          
memset(LCD_str_bot, 0, MAX_LCD_BYTES);              
}

void helper_WipeLCD_top(void){  // wipe the text top line
memset(LCD_str_top, 0, MAX_LCD_BYTES);          
}

void helper_WipeLCD_bot (void){  // wipe the text top line
memset(LCD_str_bot, 0, MAX_LCD_BYTES);          
}


/******************************************************************************
* Function Name: helper_WipeOut
*******************************************************************************
*
* Summary:
*    Wipe the buffers used to collect output from Host PC
*
*******************************************************************************/
void helper_WipeOUT(void)
{
            
memset(OUT_Data_Buffer, 0, USBUART_BUFFER_SIZE);          
  
}


/******************************************************************************
* Function Name: helper_WipeIn
*******************************************************************************
*
* Summary:
*    Wipe the buffers used to collect output from Host PC
*
*******************************************************************************/
void helper_WipeIN(void)
{
                       
memset(IN_Data_Buffer, 0, USBUART_BUFFER_SIZE);
            
}


/* [] END OF FILE */
